// Import statements
import java.util.List;  // Import the List class
public class HealthMonitoringApp {

    private static UserDao userDao = new UserDao();
    private static HealthDataDao healthDataDao = new HealthDataDao();
    private static RecommendationSystem recommendationSystem = new RecommendationSystem();
    private static MedicineReminderManager medicineReminderDao = new MedicineReminderManager();  // Use the correct class
    private static DoctorPortalDao doctorPortalDao = new DoctorPortalDao(userDao, healthDataDao);

    public static void main(String[] args) {
        DatabaseConnection databaseConnection = new DatabaseConnection();

        // Test register a new user
        testRegisterUser();
        // Test login user
        testLoginUser();
        // Test add health data
        testAddHealthData();
        // Test generate recommendations
        testGenerateRecommendations();
        // Test add a medicine reminder
        testAddMedicineReminder();
        // Test get reminders for a specific user
        testGetRemindersForUser();
        // Test get due reminders for a specific user
        testGetDueRemindersForUser();
        // Test doctor portal
        testDoctorPortal();
    }
    public static void testRegisterUser() {
        // Add code to test registering a new user
        User user1 = new User(5, "Ainee", "Malik", "qmalik@gmail.com", "guggu", false);
        userDao.createUser(user1);
    }
    public static void testLoginUser() {
        // Add code to test logging in a user
        String userEmail = "qmalik@gmail.com";
        String userPassword = "guggu";

        boolean loginSuccess = loginUser(userEmail, userPassword);
        if (loginSuccess) {
            System.out.println("Login Successful");
        } else {
            System.out.println("Incorrect email or password. Please try again.");
            // Show an error message and prompt the user to re-enter their credentials
        }
    }

    public static void testAddHealthData() {
        // Add code to test adding health data
        HealthData healthData = new HealthData(1, 5, 70.5, 170.0, 8000, 75, "2023-01-01");
        healthDataDao.createHealthData(healthData);
    }

    public static void testGenerateRecommendations() {
        // Add code to test generating recommendations
        HealthData healthData = new HealthData(1, 5, 70.5, 170.0, 8000, 75, "2023-01-01");
        List<String> recommendations = recommendationSystem.generateRecommendations(healthData);
        System.out.println("Recommendations: " + recommendations);
    }
    public static void testAddMedicineReminder() {
        // Add code to test adding a medicine reminder
        MedicineReminder medicineReminder = new MedicineReminder(1, 5, "ADHD meds idk", "3 times a day", "Schedule", "2024-01-01", "2024-01-10");
        medicineReminderDao.addReminder(medicineReminder);
    }
    public static void testGetRemindersForUser() {
        // Add code to test getting reminders for a specific user
        List<MedicineReminder> reminders = medicineReminderDao.getRemindersForUser(5);
        System.out.println("Reminders for User 5: " + reminders);
    }

    public static void testGetDueRemindersForUser() {
        // Add code to test getting due reminders for a specific user
        List<MedicineReminder> dueReminders = medicineReminderDao.getDueReminders(5);
        System.out.println("Due Reminders for User 5: " + dueReminders);
    }

    public static void testDoctorPortal() {
        // Replace the doctorId with a valid ID from your database
        int doctorId = 1;

        // Add code to test the doctor portal
        Doctor doctor = doctorPortalDao.getDoctorById(doctorId);
        List<User> patients = doctorPortalDao.getPatientsByDoctorId(doctorId);
        List<HealthData> healthData = doctorPortalDao.getHealthDataByPatientId(5);

        System.out.println("Doctor: " + doctor);
        System.out.println("Patients: " + patients);
        System.out.println("Health Data for Patient 5: " + healthData);
    }

    public static boolean loginUser(String email, String password) {
        User user = userDao.getUserByEmail(email);

        return user != null && userDao.verifyPassword(email, password);
    }
}
