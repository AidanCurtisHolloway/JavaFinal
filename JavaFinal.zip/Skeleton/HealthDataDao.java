import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class HealthDataDao {
    private Connection connection;

    public HealthDataDao() {
        // Initialize the database connection
        this.connection = DatabaseConnection.getCon();
    }

    public boolean createHealthData(HealthData healthData) {
        try (PreparedStatement preparedStatement = connection.prepareStatement("INSERT INTO health_data (user_id, weight, height, steps, heart_rate, date) VALUES (?, ?, ?, ?, ?, ?)")) {
            preparedStatement.setInt(1, healthData.getUserId());
            preparedStatement.setDouble(2, healthData.getWeight());
            preparedStatement.setDouble(3, healthData.getHeight());
            preparedStatement.setInt(4, healthData.getSteps());
            preparedStatement.setInt(5, healthData.getHeartRate());
            preparedStatement.setString(6, healthData.getDate());

            int result = preparedStatement.executeUpdate();
            return result > 0;
        } catch (SQLException e) {
            e.printStackTrace(); // Handle or log the exception appropriately
            return false;
        }
    }

    public HealthData getHealthDataById(int id) {
        try (PreparedStatement preparedStatement = connection.prepareStatement("SELECT * FROM health_data WHERE id = ?")) {
            preparedStatement.setInt(1, id);

            try (ResultSet resultSet = preparedStatement.executeQuery()) {
                if (resultSet.next()) {
                    return mapResultSetToHealthData(resultSet);
                }
            }
        } catch (SQLException e) {
            e.printStackTrace(); // Handle or log the exception appropriately
        }
        return null;
    }

    public List<HealthData> getHealthDataByUserId(int userId) {
        List<HealthData> healthDataList = new ArrayList<>();
        try (PreparedStatement preparedStatement = connection.prepareStatement("SELECT * FROM health_data WHERE user_id = ?")) {
            preparedStatement.setInt(1, userId);

            try (ResultSet resultSet = preparedStatement.executeQuery()) {
                while (resultSet.next()) {
                    healthDataList.add(mapResultSetToHealthData(resultSet));
                }
            }
        } catch (SQLException e) {
            e.printStackTrace(); // Handle or log the exception appropriately
        }
        return healthDataList;
    }

    public boolean updateHealthData(HealthData healthData) {
        try (PreparedStatement preparedStatement = connection.prepareStatement("UPDATE health_data SET user_id = ?, weight = ?, height = ?, steps = ?, heart_rate = ?, date = ? WHERE id = ?")) {
            preparedStatement.setInt(1, healthData.getUserId());
            preparedStatement.setDouble(2, healthData.getWeight());
            preparedStatement.setDouble(3, healthData.getHeight());
            preparedStatement.setInt(4, healthData.getSteps());
            preparedStatement.setInt(5, healthData.getHeartRate());
            preparedStatement.setString(6, healthData.getDate());
            preparedStatement.setInt(7, healthData.getId());

            int result = preparedStatement.executeUpdate();
            return result > 0;
        } catch (SQLException e) {
            e.printStackTrace(); // Handle or log the exception appropriately
            return false;
        }
    }

    public boolean deleteHealthData(int id) {
        try (PreparedStatement preparedStatement = connection.prepareStatement("DELETE FROM health_data WHERE id = ?")) {
            preparedStatement.setInt(1, id);

            int result = preparedStatement.executeUpdate();
            return result > 0;
        } catch (SQLException e) {
            e.printStackTrace(); // Handle or log the exception appropriately
            return false;
        }
    }

    private HealthData mapResultSetToHealthData(ResultSet resultSet) throws SQLException {
        return new HealthData(
                resultSet.getInt("id"),
                resultSet.getInt("user_id"),
                resultSet.getDouble("weight"),
                resultSet.getDouble("height"),
                resultSet.getInt("steps"),
                resultSet.getInt("heart_rate"),
                resultSet.getString("date")
        );
    }
}
