import java.util.List;

public class DoctorPortalDao {
    private UserDao userDao;
    private HealthDataDao healthDataDao;
    private MedicineReminderManager medicineReminderManager; // Assuming you have a MedicineReminderManager class

    public DoctorPortalDao(UserDao userDao2, HealthDataDao healthDataDao2) {
        userDao = new UserDao();
        healthDataDao = new HealthDataDao();
        medicineReminderManager = new MedicineReminderManager(); // Instantiate your MedicineReminderManager
    }

    public Doctor getDoctorById(int doctorId) {
        return userDao.getDoctorById(doctorId);
    }

    public List<User> getPatientsByDoctorId(int doctorId) {
        return userDao.getPatientsByDoctorId(doctorId);
    }

    public List<HealthData> getHealthDataByPatientId(int patientId) {
        return healthDataDao.getHealthDataByUserId(patientId);
    }

    // Method to schedule medicine reminders
    public void scheduleMedicineReminder( User patient, MedicineReminder medicineReminder) {
        // You may need to perform additional validation or checks before scheduling
        medicineReminderManager.addReminder(medicineReminder);
    }

    // Additional methods for other doctor-specific tasks
}
